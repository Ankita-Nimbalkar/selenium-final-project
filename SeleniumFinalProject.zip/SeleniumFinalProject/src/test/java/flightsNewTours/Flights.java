package flightsNewTours;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Flights {

	public static void main(String[] args) throws IOException, InterruptedException
	{
		
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver wb = new ChromeDriver();
		JavascriptExecutor js=(JavascriptExecutor) wb;
		wb.manage().window().maximize();
		wb.get("http://demo.guru99.com/test/newtours/");
		wb.findElement(By.linkText("Flights")).click();
		FileInputStream fis = new FileInputStream("data.xls");
		HSSFWorkbook book = new HSSFWorkbook(fis);
		HSSFSheet sh=book.getSheet("FlightsBooking");
        System.out.println("No. of records: "+ sh.getLastRowNum());
		
		for(int i=1; i<=sh.getLastRowNum(); i++)	
		{
			wb.findElement(By.linkText("Flights")).click();
		    String TripType=sh.getRow(i).getCell(0).toString();
			String Pass=sh.getRow(i).getCell(1).toString();
			String Depart=sh.getRow(i).getCell(2).toString();
			String DMonth=sh.getRow(i).getCell(3).toString();
			String Dday=sh.getRow(i).getCell(4).toString();
			String Arriving=sh.getRow(i).getCell(5).toString();
			String ReturnMonth=sh.getRow(i).getCell(6).toString();
			String Returnday=sh.getRow(i).getCell(7).toString();
			String Serviceclass=sh.getRow(i).getCell(8).toString();
			String airlines=sh.getRow(i).getCell(9).toString();
            
			System.out.println(TripType+"   "+Pass+"   "+Depart+"   "+DMonth+"   "+Dday+"   "+Arriving+"   "+ReturnMonth+"   "+Returnday+"   "+Serviceclass+"   "+airlines);
			
		    if (TripType.equalsIgnoreCase("roundtrip"))
			{
				wb.findElement(By.xpath("//tbody/tr[2]/td[2]/b[1]/font[1]/input[1]")).click();
			}
			else if (TripType.equalsIgnoreCase("oneway"))
			{
				wb.findElement(By.xpath("//tbody/tr[2]/td[2]/b[1]/font[1]/input[2]")).click();
				
			}
		Select passengers = new Select(wb.findElement(By.name("passCount")));
		passengers.selectByVisibleText(Pass);
		
		Select departing = new Select(wb.findElement(By.name("fromPort")));
		departing.selectByVisibleText(Depart);
		
		Select on = new Select(wb.findElement(By.name("fromMonth")));
		on.selectByVisibleText(DMonth);
		
		Select date = new Select(wb.findElement(By.name("fromDay")));
		date.selectByVisibleText(Dday);
		
		Select Arrival = new Select(wb.findElement(By.name("toPort")));
		Arrival.selectByVisibleText(Arriving);
		
		Select Returning = new Select(wb.findElement(By.name("toMonth")));
		Returning.selectByVisibleText(ReturnMonth);
		
		js.executeScript("window.scrollBy(0,1000)");
		Select Lastday = new Select(wb.findElement(By.name("toDay")));
		Lastday.selectByVisibleText(Returnday);
		
		if (Serviceclass.equalsIgnoreCase("Economy class"))
		{
			wb.findElement(By.xpath("//tbody/tr[9]/td[2]/font[1]/input[1]")).click();
		}
		else if (Serviceclass.equalsIgnoreCase("Business class"))
		{
			wb.findElement(By.xpath("//tbody/tr[9]/td[2]/font[1]/font[1]/input[1]")).click();
			
		}
		else if (Serviceclass.equalsIgnoreCase("First class"))
		{
			wb.findElement(By.xpath("//tbody/tr[9]/td[2]/font[1]/font[1]/input[2]")).click();
		}
		Select Airline = new Select(wb.findElement(By.name("airline")));
		Airline.selectByVisibleText(airlines);
		Thread.sleep(2000);
		if(Depart.equals(Arriving))
		{ 
			System.out.println("Test case Failed");
			wb.findElement(By.name("findFlights")).click();
			System.out.println(wb.findElement(By.xpath("//tbody/tr[1]/td[1]/p[1]/font[1]/b[1]/font[1]")).getText());
		}
		else
		{
			System.out.println("Test case Passed");
			wb.findElement(By.name("findFlights")).click();
			System.out.println(wb.findElement(By.xpath("//tbody/tr[1]/td[1]/p[1]/font[1]/b[1]/font[1]")).getText());
		}
		}
		
		wb.close();
	}
		
}

