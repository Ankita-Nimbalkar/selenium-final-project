package loginNewTours;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginNewTours {

	public static void main(String[] args) throws IOException, InterruptedException {
	{
		FileInputStream fis = new FileInputStream("data.xls");
				HSSFWorkbook book = new HSSFWorkbook(fis);
				HSSFSheet sh=book.getSheet("Login");
				System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
				WebDriver wb = new ChromeDriver();
				wb.manage().window().maximize();
				wb.get("http://demo.guru99.com/test/newtours/");
				System.out.println("No. of records: "+ sh.getLastRowNum());
				 for(int i=0; i<=sh.getLastRowNum(); i++)
				{
					String un=sh.getRow(i).getCell(0).toString();
					String pw=sh.getRow(i).getCell(1).toString();
				    System.out.println(un+"   "+pw);
					wb.findElement(By.name("userName")).sendKeys(un);
					wb.findElement(By.name("password")).sendKeys(pw);
					wb.findElement(By.name("submit")).click();
					Thread.sleep(1000);
					try
					{
					wb.findElement(By.linkText("SIGN-OFF")).click();
					}
					catch(Exception e)
					{ 
						System.out.println("Invalid Input  : "+i);
					}
				}
				wb.close();
}				
}
}