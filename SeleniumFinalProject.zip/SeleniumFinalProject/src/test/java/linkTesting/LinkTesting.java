package linkTesting;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LinkTesting {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver wb = new ChromeDriver();
		wb.manage().window().maximize();
		wb.get("http://demo.guru99.com/test/newtours/");
		
		    wb.findElement(By.linkText("Hotels")).click();
		    Thread.sleep(1000);
		    String hotel = wb.getTitle();
		    if(hotel.contains("Under Construction")|| wb.getCurrentUrl().equals("http://demo.guru99.com/test/newtours/index.php"))
        { 
			System.out.println("Hotel Page :");
	        System.out.println(wb.findElement(By.xpath("//tbody/tr[3]/td[1]/p[1]/font[1]/b[1]/font[1]")).getText());
	        System.out.println(wb.findElement(By.xpath("//font[contains(text(),' for any inconvienece.')]")).getText());
        }

		    wb.findElement(By.linkText("Car Rentals")).click();
		    Thread.sleep(1000);
		    String carrental = wb.getTitle();
		    if(carrental.contains("Under Construction")|| wb.getCurrentUrl().equals("http://demo.guru99.com/test/newtours/index.php"))
       { 
			System.out.println("Car Rentals Page :");
	        System.out.println(wb.findElement(By.xpath("//tbody/tr[3]/td[1]/p[1]/font[1]/b[1]/font[1]")).getText());
	        System.out.println(wb.findElement(By.xpath("//font[contains(text(),' for any inconvienece.')]")).getText());
       }
		    wb.findElement(By.linkText("Cruises")).click();
		    Thread.sleep(1000);
		    String cruise = wb.getTitle();
		    if(cruise.contains("Under Construction")|| wb.getCurrentUrl().equals("http://demo.guru99.com/test/newtours/index.php"))
       { 
			System.out.println("Cruises Page : Page Not Found");
	
	   }
		    wb.findElement(By.linkText("Destinations")).click();
		    Thread.sleep(1000);
		    String destination = wb.getTitle();
		    if(destination.contains("Under Construction")|| wb.getCurrentUrl().equals("http://demo.guru99.com/test/newtours/index.php"))
      { 
			System.out.println("Destinations Page :");
	        System.out.println(wb.findElement(By.xpath("//tbody/tr[3]/td[1]/p[1]/font[1]/b[1]/font[1]")).getText());
	        System.out.println(wb.findElement(By.xpath("//font[contains(text(),' for any inconvienece.')]")).getText());

	  }
		    wb.findElement(By.linkText("Vacations")).click();
		    Thread.sleep(1000);
		    String vacation = wb.getTitle();
		    if(vacation.contains("Under Construction")|| wb.getCurrentUrl().equals("http://demo.guru99.com/test/newtours/index.php"))
     { 
			System.out.println("Vecations Page :");
	        System.out.println(wb.findElement(By.xpath("//tbody/tr[3]/td[1]/p[1]/font[1]/b[1]/font[1]")).getText());
	        System.out.println(wb.findElement(By.xpath("//font[contains(text(),' for any inconvienece.')]")).getText());

	 }
		    wb.findElement(By.linkText("SUPPORT")).click();
		    Thread.sleep(1000);
		    String support = wb.getTitle();
		    if(support.contains("Under Construction")|| wb.getCurrentUrl().equals("http://demo.guru99.com/test/newtours/index.php"))
     { 
			System.out.println("Support Page :");
	        System.out.println(wb.findElement(By.xpath("//tbody/tr[3]/td[1]/p[1]/font[1]/b[1]/font[1]")).getText());
	        System.out.println(wb.findElement(By.xpath("//font[contains(text(),' for any inconvienece.')]")).getText());

	 }
		    wb.findElement(By.linkText("CONTACT")).click();
		    Thread.sleep(1000);
		    String contact = wb.getTitle();
		    if(contact.contains("Under Construction")|| wb.getCurrentUrl().equals("http://demo.guru99.com/test/newtours/index.php"))
     { 
			System.out.println("contact Page :");
	        System.out.println(wb.findElement(By.xpath("//tbody/tr[3]/td[1]/p[1]/font[1]/b[1]/font[1]")).getText());
	        System.out.println(wb.findElement(By.xpath("//font[contains(text(),' for any inconvienece.')]")).getText());

	 }
		wb.close();			
}
}
