package registrationNewTours;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Registration {

	public static void main(String[] args) throws IOException, InterruptedException 
	{
		FileInputStream fis = new FileInputStream("data.xls");
		HSSFWorkbook book = new HSSFWorkbook(fis);
		HSSFSheet sh=book.getSheet("Registration");
		HSSFSheet sh1=book.getSheet("Invalid");
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver wb = new ChromeDriver();
		wb.manage().window().maximize();
		wb.get("http://demo.guru99.com/test/newtours/");
		wb.manage().window().maximize();
		wb.findElement(By.name("userName")).sendKeys("test1");
		wb.findElement(By.name("password")).sendKeys("test1");
		wb.findElement(By.name("submit")).click();
		wb.findElement(By.linkText("REGISTER")).click();
		System.out.println("No. of records: "+ sh.getLastRowNum());
		for(int i=1; i<=sh.getLastRowNum(); i++)
		{   
			String nm=sh.getRow(i).getCell(0).toString();
			String Lstnm=sh.getRow(i).getCell(1).toString();
			String phno=sh.getRow(i).getCell(2).toString();
			String mail=sh.getRow(i).getCell(3).toString();
			String add=sh.getRow(i).getCell(4).toString();
			String city=sh.getRow(i).getCell(5).toString();
			String state=sh.getRow(i).getCell(6).toString();
			String code=sh.getRow(i).getCell(7).toString();
			String country=sh.getRow(i).getCell(8).toString();
			String Unm=sh.getRow(i).getCell(9).toString();
			String pwd=sh.getRow(i).getCell(10).toString();
			String Cpwd=sh.getRow(i).getCell(11).toString();
			
        	System.out.println(nm+"   "+Lstnm+"   "+phno+"   "+mail+"   "+add+"   "+city+"   "+state+"   "+code+"   "+country+"   "+Unm+"   "+pwd+"   "+Cpwd);
			
        	wb.findElement(By.name("firstName")).sendKeys(nm);
			wb.findElement(By.name("lastName")).sendKeys(Lstnm);
			wb.findElement(By.name("phone")).sendKeys(phno);
 			wb.findElement(By.name("userName")).sendKeys(mail);
			wb.findElement(By.name("address1")).sendKeys(add);
			wb.findElement(By.name("city")).sendKeys(city);
			wb.findElement(By.name("state")).sendKeys(state);
			wb.findElement(By.name("postalCode")).sendKeys(code);
			Thread.sleep(1000);
	        Select drpCountry = new Select(wb.findElement(By.name("country")));
		    drpCountry.selectByVisibleText(country);
            wb.findElement(By.name("email")).sendKeys(Unm);
			wb.findElement(By.name("password")).sendKeys(pwd);
	        wb.findElement(By.name("confirmPassword")).sendKeys(Cpwd);
		    Thread.sleep(2000);
			wb.findElement(By.name("submit")).click();
			if(wb.getCurrentUrl().equals("http://demo.guru99.com/test/newtours/register_sucess.php"))
			{
				System.out.println("Registration Passed");
				wb.findElement(By.linkText("REGISTER")).click();
			}
			else
			{
				System.out.println("Registration Failed");
				wb.findElement(By.linkText("REGISTER")).click();
			}
		}
		
		System.out.println("No. of Invalid records: "+ sh1.getLastRowNum());
		for(int i=1; i<=sh1.getLastRowNum(); i++)
		{
		    String name=sh1.getRow(i).getCell(0).toString();
			String Lstnm=sh1.getRow(i).getCell(1).toString();
			String phno=sh1.getRow(i).getCell(2).toString();
			String mail=sh1.getRow(i).getCell(3).toString();
			String add=sh1.getRow(i).getCell(4).toString();
			String city=sh1.getRow(i).getCell(5).toString();
			String state=sh1.getRow(i).getCell(6).toString();
			String code=sh1.getRow(i).getCell(7).toString();
			String country=sh1.getRow(i).getCell(8).toString();
			String Unm=sh1.getRow(i).getCell(9).toString();
			String pwd=sh1.getRow(i).getCell(10).toString();
			String Cpwd=sh1.getRow(i).getCell(11).toString();
			
			System.out.println(name+"   "+Lstnm+"   "+phno+"   "+mail+"   "+add+"   "+city+"   "+state+"   "+code+"   "+country+"   "+Unm+"   "+pwd+"   "+Cpwd);
			
			wb.findElement(By.name("firstName")).sendKeys(name);
			wb.findElement(By.name("lastName")).sendKeys(Lstnm);
			wb.findElement(By.name("phone")).sendKeys(phno);
 			wb.findElement(By.name("userName")).sendKeys(mail);
			wb.findElement(By.name("address1")).sendKeys(add);
			wb.findElement(By.name("city")).sendKeys(city);
			wb.findElement(By.name("state")).sendKeys(state);
			wb.findElement(By.name("postalCode")).sendKeys(code);
			Select drpCountry = new Select(wb.findElement(By.name("country")));
			drpCountry.selectByVisibleText(country);		
			wb.findElement(By.name("email")).sendKeys(Unm);
			wb.findElement(By.name("password")).sendKeys(pwd);
			wb.findElement(By.name("confirmPassword")).sendKeys(Cpwd);
			Thread.sleep(3000);
			wb.findElement(By.name("submit")).click();
			if(wb.getCurrentUrl().equals("http://demo.guru99.com/test/newtours/register_sucess.php"))
			{
				System.out.println("Registration Passed");
				wb.findElement(By.linkText("REGISTER")).click();
			}
			else
			{
				System.out.println("Registration Failed");
				wb.findElement(By.linkText("REGISTER")).click();
			}
		}
		   wb.close();
	}
	
	
	}



